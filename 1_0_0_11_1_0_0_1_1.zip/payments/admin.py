from django.contrib import admin
from payments.DisputeModel import Dispute
from payments.ProductModel import Product
# Register your models here.
admin.site.register(Product)
admin.site.register(Dispute)
