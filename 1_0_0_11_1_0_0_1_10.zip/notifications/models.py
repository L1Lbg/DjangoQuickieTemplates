from django.db import models
import uuid
from django.utils import timezone
# Create your models here.

class Notification(models.Model):
    id = models.AutoField(primary_key=True)

    title = models.CharField()
    description = models.TextField(blank=True)

    all_scope = models.BooleanField(default=True, help_text='Activate this if this notifications is meant for all users.')
    specific_scope = models.ManyToManyField(to='authentication.User', blank=True, help_text='Use this if this notification is for a specific user or users.')

    created = models.DateTimeField(auto_now_add=True)    


    def save(self, *args, **kwargs):
        
            

        super().save(*args, **kwargs)