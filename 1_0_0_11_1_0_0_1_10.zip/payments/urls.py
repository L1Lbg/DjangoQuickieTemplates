from django.contrib import admin
from django.urls import path, include, re_path
from dotenv import load_dotenv
from . import views as payment_views
import os


load_dotenv()

urlpatterns = [
    path('webhook/', payment_views.webhook),
    path('unsubscribe/', payment_views.cancel_subscription),
    path('checkout/<int:product_id>', payment_views.create_checkout_session),
]