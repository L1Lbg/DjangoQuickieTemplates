python manage.py createcachetable
python manage.py makemigrations api, payments, authentication
python manage.py migrate
python manage.py createsuperuser