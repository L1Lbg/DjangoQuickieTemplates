from django.core.mail import send_mail
from django.db import models
import os
from django.utils import timezone
from dotenv import load_dotenv
load_dotenv()

class Dispute(models.Model):
    STATUS_CHOICES = (
        ('warning_needs_response','warning_needs_response'),
        ('warning_under_review','warning_under_review'),
        ('warning_closed','warning_closed'),
        ('needs_response','needs_response'),
        ('under_review','under_review'),
        ('won','won'),   
        ('lost','lost'),        
    )

    id = models.AutoField(primary_key=True)
    user = models.ForeignKey('authentication.User', null=True, on_delete=models.SET_NULL)
    created = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=32, choices=STATUS_CHOICES)
    stripe_id = models.CharField(max_length=128)
    payment = models.ForeignKey('payments.Payment', on_delete=models.SET_NULL, null=True)
    
    def save(self, *args, **kwargs):
        if not self.id:
            send_mail(
                'Dispute created',
                'Dispute created',
                os.getenv('EMAIL_HOST_USER'),
                [os.getenv('EMAIL_HOST_USER')]
            )
            self.created = timezone.now()

        super().save(*args,**kwargs)