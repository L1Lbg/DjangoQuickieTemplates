from payments.PaymentModel import Payment
from payments.DisputeModel import Dispute
from rest_framework import serializers

# used to store payments on db
class WebhookPaymentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Payment
        fields = [
            'amount','currency', 'product',
            'user',
            'stripe_pi_id', 'stripe_checkout_id'
        ]

# used to store disputes on db
class CreateDisputeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Dispute
        fields = [
            'user', 'status', 'stripe_id'
        ]