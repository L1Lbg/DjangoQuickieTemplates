from django.core.mail import send_mail
from django.shortcuts import get_object_or_404
from payments.DisputeModel import Dispute
from payments.PaymentModel import Payment
from authentication.models import User
from payments.serializers import CreateDisputeSerializer
from rest_framework.response import Response
import os
def HandleDispute(event):
    # if dispute was created
    if event['type'] == 'charge.dispute.created':
        # alert admins that dispute was created
        send_mail(
                'Dispute on payment',
                f"""Dispute on payment. 
    Please fill this form:
    https://dashboard.stripe.com/test/disputes/{event['data']['object']['id']}/respond
                """,
                os.getenv('EMAIL_HOST_USER'),
                [os.getenv('EMAIL_HOST_USER')]
            )


        # get user and find payment related
        user = get_object_or_404(User, email=event['data']['object']['evidence']['customer_email_address'])
        payment = get_object_or_404(Payment, stripe_pi_id=event['data']['object']['payment_intent'])
        
        # create dispute
        Dispute.objects.update_or_create(
            user=user,
            status=event['data']['object']['status'],
            stripe_id=event['data']['object']['id'],
            payment=payment
        )

        # remove credits from user corresponding to disputed payment
        user.deduct_credits(payment.product.credits_to_add)

    # if there are changes with the dispute, update its status
    if event['type'] == 'charge.dispute.updated':
        
        dispute = get_object_or_404(Dispute, stripe_id=event['data']['object']['id'])

        data = {
            'status':event['data']['object']['status'],
        }

        serializer = CreateDisputeSerializer(dispute, data=data, partial=True)
        if serializer.is_valid():
            serializer.save()
        else:
            return Response(status=400)

        # alert admin that dispute has update
        send_mail(
                'Update on dispute',
                f"""There has been an update on the dispute {dispute.id}. 
New status: {data['status']}
                """,
                os.getenv('EMAIL_HOST_USER'),
                [os.getenv('EMAIL_HOST_USER')]
            )

    
    return Response(status=200)