from django.db import models
import stripe
import os 
from dotenv import load_dotenv
load_dotenv()
stripe.api_key = os.getenv('STRIPE_API_KEY')

class ProductQuerySet(models.QuerySet):
    def delete(self, *args, **kwargs):
        # Iterate over each product to deactivate its Stripe product and price before deletion
        for product in self:
            try:
                stripe.Price.modify(product.stripe_price_id, active=False)
                stripe.Product.modify(product.stripe_product_id, active=False)
            except stripe.error.StripeError as e:
                raise ValidationError(f"Stripe error occurred: {e.user_message}")
        
        # Call the superclass method to actually delete the objects
        super().delete(*args, **kwargs)

class Product(models.Model):
    objects = ProductQuerySet.as_manager()

    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=255)
    price = models.DecimalField(max_digits=10, decimal_places=2, help_text='Price in euros')
    stripe_product_id = models.CharField(max_length=255, null=True, blank=True)
    stripe_price_id = models.CharField(max_length=255, null=True, blank=True)


    def __str__(self):
        return f"{self.name}, {self.price}"


    def save(self, *args, **kwargs):
        recurring = {
            'interval':'month',
            'interval_count':1 # every 1 month
        }
        if not self.stripe_product_id:

            #* create the price with the product data inside
            price = stripe.Price.create(
                currency="eur",
                unit_amount_decimal=self.price*100,
                recurring=recurring,
                product_data={
                    'name':self.name
                },
            )
            self.stripe_product_id = price['product']
            self.stripe_price_id = price['id']

        else:
            old_price = self.stripe_price_id

            #* Create new price
            price = stripe.Price.create(
                currency="eur",
                unit_amount_decimal=self.price*100,
                recurring=recurring,
                product=self.stripe_product_id,
            )
            self.stripe_price_id = price['id']

            #* assign the new price to the product
            #* apply other product modifications
            product = stripe.Product.modify(
                self.stripe_product_id,
                default_price = price['id'],
                name = self.name
            )

            #* deactivate the old price
            stripe.Price.modify(old_price, active=False)

        super().save(*args, **kwargs)