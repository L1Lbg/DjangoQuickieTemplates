
from django.urls import path, include
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from . import views as auth_views
from authentication.google.GoogleLoginRedirect import GoogleLoginRedirectApi
from authentication.google.GoogleLoginRedirect import GoogleLoginApi


urlpatterns = [
    path('oauth2/get-redirect', GoogleLoginRedirectApi.as_view(), name='OAuth2_get_redirect'),
    path('oauth2/login', GoogleLoginApi.as_view(), name='OAuth2_handle_login'),
    path('token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),    
    path('logout', auth_views.logout),
    path('manage/users/set_email/', auth_views.forbidden),
    path('manage/users/reset_email/', auth_views.forbidden),
    path('manage/users/reset_email_confirm/', auth_views.forbidden),
    path('manage/users/set_password/', auth_views.forbidden),
    path(r'manage/', include('djoser.urls')),
]

