from django.urls import path, include
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from . import views as auth_views
import os

urlpatterns = [
    path('token/', TokenObtainPairView.as_view(), name='token_obtain_pair'), # login
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'), # refresh JWT Token
    path('logout', auth_views.logout), # blacklist refresh token
    path(r'manage/', include('djoser.urls')), # let's user manage their accounts
]