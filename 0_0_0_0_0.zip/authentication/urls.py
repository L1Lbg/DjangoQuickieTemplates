from django.contrib import admin
from django.urls import path, include, re_path
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from dotenv import load_dotenv
from . import views as auth_views
import os

# from authentication.views import GoogleLoginView, UserRedirectView

load_dotenv()

urlpatterns = [
    path('token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),    
    path('logout', auth_views.logout),
    path('manage/users/set_email/', auth_views.forbidden),
    path('manage/users/reset_email/', auth_views.forbidden),
    path('manage/users/reset_email_confirm/', auth_views.forbidden),
    path('manage/users/set_password/', auth_views.forbidden),
    path(r'manage/', include('djoser.urls')),


]