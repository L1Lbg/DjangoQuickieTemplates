from rest_framework.response import Response
from rest_framework.decorators import api_view, throttle_classes, authentication_classes, permission_classes
from rest_framework.permissions import AllowAny
from dotenv import load_dotenv
from django.template.loader import render_to_string 
from django.core.mail import EmailMessage
from django.utils.html import strip_tags
from payments.serializers import *
from django.core.mail import send_mail
from payments.DisputeModel import Dispute
from payments.ProductModel import Product
from payments.PaymentModel import Payment
from django.shortcuts import get_object_or_404
import os
import time
import stripe
from project.settings import DEBUG
load_dotenv()

stripe.api_key = os.getenv('STRIPE_API_KEY')
endpoint_secret = os.getenv('ENDPOINT_SECRET')


@api_view(['POST'])
def create_checkout_session(request, product_id):
    if request.user.stripe_id == None:
        request.user.create_stripe_account()
        return Response({'error':"You do not have a Stripe ID, please try again in a few seconds."}, status=400)
    
    #* GET THE PRODUCT STRIPE PRICE ID
    product = get_object_or_404(Product, id=product_id)
    product_price = product.stripe_price_id 

    
    mode = 'payment'
    payment_intent_data = {
        "setup_future_usage":'off_session',
        'capture_method':'manual',
        'receipt_email':request.user.email
    }



    #todo: check if user has unresolved disputes

    #todo ----------------------
    

    try:
        checkout_session = stripe.checkout.Session.create(
            ui_mode='hosted',
            # billing_address_collection='required',
            #https://stripe.com/docs/api/checkout/sessions/create#create_checkout_session-shipping_options
            customer=request.user.stripe_id,
            line_items=[
                {
                    'price':product_price,
                    'quantity':1
                },
            ],
            mode=mode,
            consent_collection = {
                #! 'terms_of_service':"required", 
            },
            # phone_number_collection = {'enabled':True},
            payment_method_types=['card', 'paypal'],
            payment_intent_data=payment_intent_data,
            currency='eur',
            # custom_fields=[],
            # custom_text={},
            # discount=[{}],

            # locale=request.user.lang,
            expires_at=int(time.time() + 30*60),
            success_url= f'{os.getenv("FRONTEND_URL")}/orders?success=true',
            cancel_url=  f'{os.getenv("FRONTEND_URL")}/orders?success=false',
        )

        #* CREATE A PAYMENT MODEL
        data = {
            'user':request.user.id,
            'stripe_checkout_id':checkout_session['id'],
            'product':product_id,
            'amount':0
        }
        serializer = WebhookPaymentSerializer(data=data)

        if serializer.is_valid():
            serializer.save()
        else:
            print(serializer.errors)
            return Response({'error':"Couldn't create checkout."}, status=400)

    except Exception as e:
        print(e)
        return Response({'error':"Couldn't create checkout."}, status=400)

    return Response({'url':checkout_session.url}, status=303) 


@api_view(['POST'])
@authentication_classes([])  
@permission_classes([AllowAny])
@throttle_classes([])
def webhook(request):
    event = None
    payload = request.body.decode('utf-8')
    sig_header = request.headers.get('Stripe_Signature')
    try:
        event = stripe.Webhook.construct_event(
            payload, sig_header, endpoint_secret
        )
    except Exception as e:
        print(e)
        return Response({'error':f"{e}"}, status=400)

    if DEBUG:
        os.makedirs(os.path.dirname('./log/stripe/'), exist_ok=True)
        with open(f'./log/stripe/{event["type"]}.json', 'w') as f:
            f.write(str(event))

    data = dict()
    if event['type'] == 'checkout.session.completed':
        #* get payment and update with new data
        payment = get_object_or_404(Payment, stripe_checkout_id=event['data']['object']['id'], user__email=event['data']['object']['customer_details']['email'])
        data['stripe_pi_id'] = event['data']['object']['payment_intent']
        data['amount'] = event['data']['object']['amount_total']
        data['currency'] = event['data']['object']['currency']
        serializer = WebhookPaymentSerializer(payment, data=data, partial=True)

        #* save and claim reward for user
        if serializer.is_valid():
            serializer.save()
            payment.claim_reward()
        else:
            return Response({'error':serializer.errors}, status=400)

    if event['type'] == 'checkout.session.expired':
        #* delete unpaid payment object from DB
        payment = get_object_or_404(Payment, stripe_checkout_id=event['data']['object']['id'])
        payment.delete()

    if event['type'] == 'payment_intent.canceled':

        payment = get_object_or_404(Payment, stripe_pi_id=event['data']['object']['id'])
        
        #* collect data for mail 
        context = {
            'customer_name':payment.user.username,
            'product_name':payment.product.name,
            'product_link':payment.product.id,
            'purchase_date':payment.time
        }

        #* configure and send mail
        subject = 'Payment was canceled'
        html_message = render_to_string('en/failed_purchase.html', context)
        from_email = f'{os.getenv("NAME")}'
        to = payment.user.email


        message = EmailMessage(subject, html_message, from_email, [to])
        message.content_subtype = 'html'
        message.send()
       
        #* delete payment object from DB
        payment.delete()

    if event['type'] == 'payment_intent.succeeded':
        #* get product
        payment = get_object_or_404(Payment, stripe_pi_id=event['data']['object']['id'])

        #* collect data for mail 
        context = {
            'customer_name':payment.user.username,
            'product_name':payment.product.name,
            'product_link':payment.product.id,
            'purchase_date':payment.time
        }

        #* configure and send mail
        subject = 'Payment was successfully completed'

        html_message = render_to_string('en/successful_purchase.html', context)
        from_email = f'{os.getenv("NAME")}'
        to = payment.user.email


        message = EmailMessage(subject, html_message, from_email, [to])
        message.content_subtype = 'html' # this is required because there is no plain text email message
        message.send()


    if 'charge.dispute.' in event['type']:
        send_mail(
            'Dispute on payment',
            'Dispute on payment',
            os.getenv('EMAIL_HOST_USER'),
            [os.getenv('EMAIL_HOST_USER')]
        )

    return  Response(status=204)