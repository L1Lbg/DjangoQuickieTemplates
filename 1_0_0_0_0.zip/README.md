python manage.py createcachetable
python manage.py makemigrations api, payments, authentication