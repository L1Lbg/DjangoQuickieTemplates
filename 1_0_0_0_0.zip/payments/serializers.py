from payments.DisputeModel import Dispute
from rest_framework import serializers

class CreateDisputeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Dispute
        fields = [
            'user', 'status', 'stripe_id'
        ]