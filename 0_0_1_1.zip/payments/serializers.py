from payments.PaymentModel import Payment
from rest_framework import serializers
class WebhookPaymentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Payment
        fields = [
            'amount','currency', 'product',
            'user',
            'stripe_pi_id', 'stripe_checkout_id'
        ]