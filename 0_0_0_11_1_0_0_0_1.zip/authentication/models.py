from django.db import models
from django.contrib.auth.models import AbstractUser
from django.contrib.auth.base_user import BaseUserManager
import stripe
import os
from payments.DisputeModel import Dispute
from dotenv import load_dotenv
load_dotenv()

stripe.api_key = os.getenv('STRIPE_API_KEY')

class CustomUserManager(BaseUserManager):
    """
    Custom user model manager where email is the unique identifiers
    for authentication instead of usernames.
    """
    def create_user(self, email, password, **extra_fields):
        if not email:
            raise ValueError(_("The Email must be set"))
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save()
        return user

    def create_superuser(self, email, password, **extra_fields):
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)
        extra_fields.setdefault("is_active", True)

        if extra_fields.get("is_staff") is not True:
            raise ValueError(_("Superuser must have is_staff=True."))
        if extra_fields.get("is_superuser") is not True:
            raise ValueError(_("Superuser must have is_superuser=True."))
        return self.create_user(email, password, **extra_fields)

class User(AbstractUser):
    registration_choices = (
        ('Mail', 'Mail'),
        ('Google', 'Google'),
        ('Apple', 'Apple'),
    )
    email = models.EmailField(max_length=255, unique=True)
    username=models.CharField(max_length=128, default='username')
    registration_method = models.CharField(choices=registration_choices,default='Mail')
    stripe_id = models.CharField(default=None, null=True, blank=True)

    credits = models.IntegerField(default=0)

    new_ban=models.BooleanField(help_text='Always activate this if you want to apply a new ban.', default=False)
    ban_limit=models.DateTimeField(blank=True,null=True)
    indefinite_ban=models.BooleanField(default=False)
    ban_reason=models.TextField(blank=True, default="Your conduct violates the community rules.")
    
    username=None
    first_name=None
    last_name=None
    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = []
    objects = CustomUserManager()


    def create_stripe_account(self):
        if self.stripe_id != None:
            return

        event = stripe.Customer.create( # https://docs.stripe.com/api/customers/create?lang=python
            name=self.username,
            email=self.email,
        )

        self.stripe_id =  event['id']
        self.save()

    # use this method after/before every API operation
    def deduct_credits(self, num):
        self.credits -= num
        self.save()


    def check_disputes(self): # if user has more than 0 undisclosed disputes, return True
        if len(Dispute.objects.filter(user=self).exclude(status='won')) > 0:
            return True
        else: 
            False