from django.contrib import admin
from payments.DisputeModel import Dispute
from payments.ProductModel import Product
from payments.PaymentModel import Payment
# Register your models here.
admin.site.register(Product)
admin.site.register(Payment)
admin.site.register(Dispute)
