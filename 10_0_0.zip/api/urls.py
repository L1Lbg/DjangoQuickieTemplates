from . import views as api_views
from django.urls import path


urlpatterns = [
    path('health', api_views.health),
]