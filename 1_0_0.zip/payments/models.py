from django.db import models
import stripe
import os 
from dotenv import load_dotenv
from .PaymentModel import Payment
from .ProductModel import Product
load_dotenv()

stripe.api_key = os.getenv('STRIPE_API_KEY')


class Dispute(models.Model):
    id = models.AutoField(primary_key=True)
    stripe_id = models.CharField(max_length=128)
    customer = models.ForeignKey('authentication.User', on_delete=models.SET_NULL, null=True)