from django.core.mail import send_mail
from django.shortcuts import get_object_or_404
from payments.DisputeModel import Dispute
from payments.PaymentModel import Payment
from authentication.models import User
from payments.serializers import CreateDisputeSerializer
from rest_framework.response import Response
import os
def HandleDispute(event):
    if event['type'] == 'charge.dispute.created':
        user = get_object_or_404(User, email=event['data']['object']['evidence']['customer_email_address'])
        payment = get_object_or_404(Payment, stripe_pi_id=event['data']['object']['payment_intent'])
        
        Dispute.objects.update_or_create(
            user=user,
            status=event['data']['object']['status'],
            stripe_id=event['data']['object']['id'],
            payment=payment
        )

        user.deduct_credits(payment.product.credits_to_add)

        send_mail(
                'Dispute on payment',
                f"""Dispute on payment. 
    Please fill this form:
    https://dashboard.stripe.com/test/disputes/{event['data']['object']['id']}/respond
                """,
                os.getenv('EMAIL_HOST_USER'),
                [os.getenv('EMAIL_HOST_USER')]
            )

    if event['type'] == 'charge.dispute.updated':
        dispute = get_object_or_404(Dispute, stripe_id=event['data']['object']['id'])

        data = {
            'status':event['data']['object']['status'],
        }

        serializer = CreateDisputeSerializer(dispute, data=data, partial=True)
        if serializer.is_valid():
            serializer.save()
        else:
            return Response(status=400)


        send_mail(
                'Update on dispute',
                f"""There has been an update on the dispute {dispute.id}. 
New status: {data['status']}
                """,
                os.getenv('EMAIL_HOST_USER'),
                [os.getenv('EMAIL_HOST_USER')]
            )

    
    return Response(status=200)