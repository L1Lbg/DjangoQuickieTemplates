from django.contrib import admin
from .models import *
# Register your models here.
@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ('email','registration_method','last_login','is_active','date_joined','is_superuser')
    search_fields = ('email',)