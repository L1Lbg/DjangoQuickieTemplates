from . import views as api_views
from . import health 
from django.urls import path


urlpatterns = [
    path('health', health.health),
]