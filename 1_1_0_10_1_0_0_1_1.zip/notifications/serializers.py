from rest_framework import serializers
from notifications.models import Notification

# used for when user requests their notifications
class NotificationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Notification

        fields = [
            'id','title', 'description','created'
        ]