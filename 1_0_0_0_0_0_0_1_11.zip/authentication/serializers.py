from authentication.models import User
from rest_framework import serializers

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = [
            'email', 'username', 
        ]


class UserSubSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = [
            'stripe_subscription_id','sub_product'
        ]