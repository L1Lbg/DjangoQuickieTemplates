from rest_framework.response import Response
from rest_framework.decorators import api_view, authentication_classes, permission_classes
import time
from authentication.models import User
import os 
import stripe
import psutil
from dotenv import load_dotenv
load_dotenv()

stripe.api_key = os.getenv('STRIPE_API_KEY')

@api_view(['GET'])
def health(request):
    res = {
        "database":'unknown',
        'server':'unknown',
    }
    try:
        #* check database connection 
        start = time.time()

        users = User.objects.all()
        user = User.objects.filter(email=os.getenv('EMAIL_HOST_USER'))

        #* do some "modification" to the database queries, to force django to query them
        str(users)
        str(user)
        res['database'] = f"{round((time.time() - start) * 1000, 5)} ms to query 2 rows."


        #* check server usage
        load = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory().percent
        res['server']  = f"{load}% CPU Usage, {memory}% Memory Usage"


    except Exception as e:
        #* define other services as ready, find the one that caused the error, and leave the others as unknown
        for key in res.keys():
            if res[key] != None:
                pass
            if res[key] == None:
                res[key] = f"Error: {e}"
                break
    return Response(res, status=200)