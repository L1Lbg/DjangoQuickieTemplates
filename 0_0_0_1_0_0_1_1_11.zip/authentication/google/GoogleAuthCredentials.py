from attrs import define
from django.conf import settings
from django.core.exceptions import ImproperlyConfigured
import os
from dotenv import load_dotenv
load_dotenv()

@define
class GoogleLoginCredentials:
    client_id: str
    client_secret: str
    project_id: str
    
def google_login_get_credentials() -> GoogleLoginCredentials:
    client_id = os.getenv('GOOGLE_OAUTH_CLIENT_ID')
    client_secret = os.getenv('GOOGLE_OAUTH_CLIENT_SECRET')
    project_id = os.getenv('GOOGLE_OAUTH_PROJECT_ID')

    if not client_id:
        raise ImproperlyConfigured("GOOGLE_OAUTH_CLIENT_ID missing in env.")

    if not client_secret:
        raise ImproperlyConfigured("GOOGLE_OAUTH_CLIENT_SECRET missing in env.")

    if not project_id:
        raise ImproperlyConfigured("GOOGLE_OAUTH_PROJECT_ID missing in env.")

    credentials = GoogleLoginCredentials(
        client_id=client_id,
        client_secret=client_secret, 
        project_id=project_id
    )

    return credentials