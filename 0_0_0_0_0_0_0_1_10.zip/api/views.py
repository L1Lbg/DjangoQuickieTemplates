from rest_framework.response import Response
from .models import *
from django.views.decorators.cache import cache_page
from .serializers import * 
from django.core.mail import send_mail
from django.shortcuts import get_object_or_404
from rest_framework.decorators import api_view, authentication_classes, permission_classes
from dotenv import load_dotenv
import os
from django.utils import timezone
from project.settings import DEBUG
load_dotenv()


# view to partially get api key details
@api_view(['GET'])
def PartiallyGetAPIKey(request, pk):
    query = get_object_or_404(APIKey, user=request.user, id=pk)
    serializer = PartialAPIKeySerializer(query)
    return Response(serializer.data, status=200) 


# view to fully get api key details
@api_view(['GET'])
def GetAPIKey(request, pk):
    query = get_object_or_404(APIKey, user=request.user, id=pk)
    serializer = FullAPIKeySerializer(query)
    return Response(serializer.data, status=200)  

# view to get all API Keys from user
@api_view(['GET'])
def GetUserAPIKeys(request):
    query = APIKey.objects.filter(user=request.user)
    serializer = PartialAPIKeySerializer(query, many=True)
    return Response(serializer.data, status=200)

# view to delete api key
@api_view(['DELETE'])
def DeleteAPIKey(request, pk):
    query = get_object_or_404(APIKey, user=request.user, id=pk)
    try:
        query.delete()
        return Response(status=204)  
    except:
        return Response(status=400)
    
# view to create api key
@api_view(['POST'])
def CreateAPIKey(request):
    serializer = CreateAPIKeySerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        # save APIKey, return full information to user
        serializer = FullAPIKeySerializer(serializer.data)
        return Response(serializer.data, status=200)
    else:
        return Response(status=400)
