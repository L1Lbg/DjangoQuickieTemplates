from rest_framework.response import Response
from rest_framework.decorators import api_view, throttle_classes, authentication_classes, permission_classes
from rest_framework.permissions import AllowAny
from dotenv import load_dotenv
from django.template.loader import render_to_string 
from authentication.models import User
from django.core.mail import EmailMessage
from django.utils.html import strip_tags
from authentication.serializers import *
from django.utils.timezone import make_aware
from django.core.mail import send_mail
from payments.DisputeModel import Dispute
from payments.HandleDispute import HandleDispute
from payments.ProductModel import Product
from django.shortcuts import get_object_or_404
import os
import time
from datetime import datetime
import stripe
from django.utils import timezone
from project.settings import DEBUG
load_dotenv()

stripe.api_key = os.getenv('STRIPE_API_KEY')
endpoint_secret = os.getenv('ENDPOINT_SECRET')


@api_view(['POST'])
def cancel_subscription(request):
    if request.user.cancel_subscription():
        return Response({"message": "Subscription cancelled successfully"}, status=200)
    else:
        return Response({"error": "Subscription not found"}, status=404)


@api_view(['POST'])
def create_checkout_session(request, product_id):
    if request.user.stripe_id == None:
        request.user.create_stripe_account()
        return Response({'error':"You do not have a Stripe ID, please try again in a few seconds."}, status=400)


    if request.user.is_subscribed():
        if  request.user.sub_product.id == product_id:
            #* prevent already subscribed user from subscribing again 
            return Response({'error':"Your subscription is still ongoing, please renew it when it is expired."},status=200)
        else:
            #* if user is subscribing to different product
            #* cancel last subscription
            request.user.cancel_subscription()

    #* GET THE PRODUCT STRIPE PRICE ID
    product = get_object_or_404(Product, id=product_id)
    product_price = product.stripe_price_id 

    mode = 'subscription'



    #todo: check if user has unresolved disputes



    #todo ----------------------
    

    try:
        checkout_session = stripe.checkout.Session.create(
            ui_mode='hosted',
            customer=request.user.stripe_id,
            line_items=[
                {
                    'price':product_price,
                    'quantity':1
                },
            ],
            mode=mode,
            consent_collection = {
                #! 'terms_of_service':"required", 
            },
            payment_method_types=['card', 'paypal'],
            currency='eur',

            expires_at=int(time.time() + 30*60),
            success_url= f'{os.getenv("FRONTEND_URL")}/orders?success=true',
            cancel_url=  f'{os.getenv("FRONTEND_URL")}/orders?success=false',
        )

    except Exception as e:
        print(e)
        return Response({'error':"Couldn't create checkout."}, status=400)

    return Response({'url':checkout_session.url}, status=303) 


@api_view(['POST'])
@authentication_classes([])  
@permission_classes([AllowAny])
@throttle_classes([])
def webhook(request):
    event = None
    payload = request.body.decode('utf-8')
    sig_header = request.headers.get('Stripe_Signature')
    try:
        event = stripe.Webhook.construct_event(
            payload, sig_header, endpoint_secret
        )
    except Exception as e:
        print(e)
        return Response({'error':f"{e}"}, status=400)

    if DEBUG:
        os.makedirs(os.path.dirname('./log/stripe/'), exist_ok=True)
        with open(f'./log/stripe/{event["type"]}.json', 'w') as f:
            f.write(str(event))


    if event['type'] == 'customer.subscription.updated':
        user = get_object_or_404(User, stripe_id=event['data']['object']['customer'])

        sub_expiry = make_aware(datetime.fromtimestamp(event['data']['object']['current_period_end']))
        product = get_object_or_404(Product, stripe_product_id=event['data']['object']['plan']['product'])

        data = {
            'sub_expiry': sub_expiry,
            'stripe_subscription_id':event['data']['object']['id'],
            'sub_product':product.id,
        }

        subject = 'Subscription Successfully Created'
        body = 'Thank you for subscribing! Your subscription is now active.'
        send_mail(
            subject,
            body,
            os.getenv('EMAIL_HOST_USER'),
            [user.email]
        )

        serializer = UserSubSerializer(user, data=data)
        if serializer.is_valid():
            serializer.save()
        else:
            print(serializer.errors)
            return Response({'error':serializer.errors}, status=400)

    if 'charge.dispute.' in event['type']:
        #* on sub-based, cancel user subscription when dispute is created
        if event['type'] == 'charge.dispute.created':
            user = get_object_or_404(User, email=event['data']['object']['evidence']['customer_email_address'])
            user.cancel_subscription()

        #* do some other processing
        return HandleDispute(event)

    return Response(status=204)