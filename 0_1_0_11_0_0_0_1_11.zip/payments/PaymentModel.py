from django.db import models
import stripe
import os 
from dotenv import load_dotenv
load_dotenv()
stripe.api_key = os.getenv('STRIPE_API_KEY')

class Payment(models.Model):
    id = models.AutoField(primary_key=True)

    user = models.ForeignKey('authentication.User', on_delete=models.SET_NULL, null=True, blank=True)

    claimed = models.BooleanField(default=False) # if the payment reward (credits), were successfully given to user

    amount = models.FloatField()
    time = models.TimeField(auto_now_add=True)
    currency = models.CharField(default='EUR')

    product = models.ForeignKey('payments.Product', on_delete=models.SET_NULL, null=True)

    stripe_checkout_id = models.CharField(max_length=256, default='')
    stripe_pi_id = models.CharField(max_length=256, default='')

    def __str__(self):
        return f"{self.product.name}, {self.amount}"