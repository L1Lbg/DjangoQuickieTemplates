from django.shortcuts import redirect
from rest_framework.views import APIView
from authentication.google.GoogleLoginFlowService import GoogleLoginFlowService
from authentication.models import User
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.response import Response
import os
import urllib.parse
from django.http import HttpResponseRedirect
from dotenv import load_dotenv
load_dotenv()

class PublicApi(APIView):
    authentication_classes = ()
    permission_classes = ()


#* this is for when user starts login attempt
class GoogleLoginRedirectApi(PublicApi):
    def get(self, request, *args, **kwargs):
        google_login_flow = GoogleLoginFlowService()

        authorization_url, state = google_login_flow.get_authorization_url()

        request.session["google_oauth2_state"] = state

        return redirect(authorization_url)

#* this is for when user is logged in by google
#* this view returns the user tokens after creating/logging in the user
class GoogleLoginApi(PublicApi):
    def get(self, request, *args, **kwargs):
        # Here we have made the request validation.
        code = request.GET.get('code')
        state = request.GET.get('state')
        
        google_login_flow = GoogleLoginFlowService()

        google_tokens = google_login_flow.get_tokens(code=code, state=state)

        id_token_decoded = google_tokens.decode_id_token()

        user_email = id_token_decoded["email"]
        user = User.objects.filter(email=user_email)

        # Here instead, handle user creation
        if not user.exists():
            user = User.objects.create(email=user_email, registration_method='Google')
            refresh = RefreshToken.for_user(user)
            res = {
                'refresh': str(refresh),
                'access': str(refresh.access_token),
            }
        else:
            refresh = RefreshToken.for_user(user.get())
            res = {
                'refresh': str(refresh),
                'access': str(refresh.access_token),
            }

        

        access_param = urllib.parse.quote_plus(str(refresh.access_token))
        refresh_param = urllib.parse.quote_plus(str(refresh))
        url = f"{os.getenv('FRONTEND_URL')}/google/login?access={access_param}&refresh={refresh_param}&email={user_email}"

        return HttpResponseRedirect(url)
