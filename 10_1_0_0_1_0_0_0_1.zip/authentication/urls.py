from django.urls import path, include
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from . import views as auth_views
import os

urlpatterns = [
    path('token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),    
    path('logout', auth_views.logout),
    path('manage/users/set_email/', auth_views.forbidden),
    path('manage/users/reset_email/', auth_views.forbidden),
    path('manage/users/reset_email_confirm/', auth_views.forbidden),
    path('manage/users/set_password/', auth_views.forbidden),
    path(r'manage/', include('djoser.urls')),
]