from rest_framework import serializers
from api.models import APIKey


class PartialAPIKeySerializer(serializers.ModelSerializer):
    id = serializers.SerializerMethodField()
    
    class Meta:
        model = APIKey
        fields = [
            'id',
            'created', 'expiry'
            'name','user',
            'public'
        ]
    # logic to hide API key
    def get_id(self, obj):
        return obj[0:5] + '*'*15
    

class FullAPIKeySerializer(serializers.ModelSerializer):    
    class Meta:
        model = APIKey
        fields = [
            'id',
            'created', 'expiry'
            'name','user',
        ]


class CreateAPIKeySerializer(serializers.ModelSerializer):    
    class Meta:
        model = APIKey
        fields = [
            'name'
        ]