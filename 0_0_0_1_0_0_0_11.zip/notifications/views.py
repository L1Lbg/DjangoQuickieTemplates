from rest_framework.response import Response
from .models import *
from .serializers import *
from django.shortcuts import get_object_or_404
from rest_framework.decorators import api_view
from notifications.models import Notification
from notifications.serializers import NotificationSerializer

@api_view(['GET'])
def get_notifications(request):
    notifications = (
        Notification.objects.filter(all_scope=True, created__gte=request.user.date_joined) |
        Notification.objects.filter(specific_scope=request.user)
    ).distinct()
    print(notifications)
    serializer = NotificationSerializer(notifications, many=True)
    return Response(serializer.data, status=200)
