from payments.PaymentModel import Payment
from payments.DisputeModel import Dispute
from rest_framework import serializers
class WebhookPaymentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Payment
        fields = [
            'amount','currency', 'product',
            'user',
            'stripe_pi_id', 'stripe_checkout_id'
        ]


class CreateDisputeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Dispute
        fields = [
            'user', 'status', 'stripe_id'
        ]