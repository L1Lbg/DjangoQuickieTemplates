from django.db import models
import uuid
from django.utils import timezone
# Create your models here.

class APIKey(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    created = models.DateTimeField()
    expiry = models.DateTimeField()

    name = models.CharField(max_length=128) # custom name given by user to recognise key
    user = models.ForeignKey('authentication.User', on_delete=models.CASCADE, null=True)

    # add some custom logic like API Key scopes

    # .................

    def save(self, *args, **kwargs):
        if not self.id:
            self.created = timezone.now()
        return super().save(*args, **kwargs)