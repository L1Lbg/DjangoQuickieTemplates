from django.contrib import admin
from django.urls import path, include, re_path
from dotenv import load_dotenv
from . import views as payment_views
import os



urlpatterns = [
    path('webhook/', payment_views.webhook),
    path('checkout/<int:product_id>', payment_views.create_checkout_session),
]