from django.db import models
import stripe
import os
from dotenv import load_dotenv
load_dotenv()
stripe.api_key = os.getenv('STRIPE_API_KEY')


class Payment(models.Model):
    id = models.AutoField(primary_key=True)

    user = models.ForeignKey('authentication.User', on_delete=models.SET_NULL, null=True, blank=True)

    claimed = models.BooleanField(default=False)

    amount = models.FloatField()
    time = models.TimeField(auto_now_add=True)
    currency = models.CharField(default='EUR')

    product = models.ForeignKey('payments.Product', on_delete=models.SET_NULL, null=True)

    stripe_checkout_id = models.CharField(max_length=256, default='')
    stripe_pi_id = models.CharField(max_length=256, default='')

    def __str__(self):
        return f"{self.product.name}, {self.amount}"

    #* GIVE PRODUCT TO USER
    def claim_reward(self):
        if self.claimed:
            return 


        #* if any error happens while claiming, automatically cancel the Payment
        try:
            if 'credits' in self.product.name.lower():
                credits_to_add = int(self.product.name.lower().replace('credits', ''))
                self.user.credits += credits_to_add
                self.user.save()

            #* if type of payment not found, return
            else:
                stripe.PaymentIntent.cancel(self.stripe_pi_id)
                return

        except Exception as e:
            print(e)
            stripe.PaymentIntent.cancel(self.stripe_pi_id)
            return

        #* claim payment
        stripe.PaymentIntent.capture(self.stripe_pi_id)
        self.claimed = True
        self.save()