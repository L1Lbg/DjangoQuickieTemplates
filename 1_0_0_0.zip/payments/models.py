from django.db import models
import stripe
import os 
from dotenv import load_dotenv
from .PaymentModel import Payment
from .ProductModel import Product
load_dotenv()

stripe.api_key = os.getenv('STRIPE_API_KEY')

