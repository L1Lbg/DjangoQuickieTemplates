from rest_framework.response import Response
from rest_framework.decorators import api_view, throttle_classes, authentication_classes, permission_classes
from rest_framework.permissions import AllowAny
from dotenv import load_dotenv
from authentication.models import User
from django.template.loader import render_to_string 
from django.core.mail import EmailMessage
from django.utils.html import strip_tags
from payments.serializers import *
from django.core.mail import send_mail
from payments.DisputeModel import Dispute
from payments.ProductModel import Product
from payments.PaymentModel import Payment
from payments.HandleDispute import HandleDispute
from django.shortcuts import get_object_or_404
import os
import time
import stripe
from project.settings import DEBUG
load_dotenv()

stripe.api_key = os.getenv('STRIPE_API_KEY')
endpoint_secret = os.getenv('ENDPOINT_SECRET')


@api_view(['POST'])
def create_checkout_session(request, product_id):
    if request.user.stripe_id == None:
        request.user.create_stripe_account()
        return Response({'error':"You do not have a Stripe ID, please try again in a few seconds."}, status=400)
    
    #* GET THE PRODUCT STRIPE PRICE ID
    product = get_object_or_404(Product, id=product_id)
    product_price = product.stripe_price_id 


    try:
        checkout_session = stripe.checkout.Session.create(
            ui_mode='hosted',
            # https://docs.stripe.com/api/checkout/sessions/create
            customer=request.user.stripe_id,
            line_items=[
                {
                    'price':product_price,
                    'quantity':1
                },
            ],
            mode='payment',
            payment_method_types=['card', 'paypal'],
            payment_intent_data={
                "setup_future_usage":'off_session',
                'capture_method':'manual',
                'receipt_email':request.user.email
            },
            currency='eur',

            expires_at=int(time.time() + 30*60),
            success_url= f'{os.getenv("FRONTEND_URL")}/orders?success=true',
            cancel_url=  f'{os.getenv("FRONTEND_URL")}/orders?success=false',
        )

        #* CREATE A PAYMENT MODEL
        data = {
            'user':request.user.id,
            'stripe_checkout_id':checkout_session['id'],
            'product':product_id,
            'amount':0
        }
        serializer = WebhookPaymentSerializer(data=data)

        if serializer.is_valid():
            serializer.save()
        else:
            return Response({'error':"Couldn't create checkout."}, status=400)

    except Exception as e:
        return Response({'error':"Couldn't create checkout."}, status=400)

    return Response({'url':checkout_session.url}, status=303) 


@api_view(['POST'])
@authentication_classes([])  
@permission_classes([AllowAny])
@throttle_classes([])
def webhook(request):
    event = None
    payload = request.body.decode('utf-8')
    sig_header = request.headers.get('Stripe_Signature')
    try:
        event = stripe.Webhook.construct_event(
            payload, sig_header, endpoint_secret
        )
    except Exception as e:
        print(e)
        return Response({'error':f"{e}"}, status=400)

    # store webhook messages in the log directory
    if DEBUG:
        os.makedirs(os.path.dirname('./log/stripe/'), exist_ok=True)
        with open(f'./log/stripe/{event["type"]}.json', 'w') as f:
            f.write(str(event))


    data = dict()

    # if user completed checkout
    if event['type'] == 'checkout.session.completed':
        #* get payment and update with new data
        payment = get_object_or_404(Payment, stripe_checkout_id=event['data']['object']['id'], user__email=event['data']['object']['customer_details']['email'])
        data['stripe_pi_id'] = event['data']['object']['payment_intent']
        data['amount'] = event['data']['object']['amount_total']
        data['currency'] = event['data']['object']['currency']
        serializer = WebhookPaymentSerializer(payment, data=data, partial=True)

        #* claim payment intent
        stripe.PaymentIntent.capture( # https://docs.stripe.com/api/payment_intents/capture
            event['data']['object']['payment_intent']
        )
        
        #* save and claim reward for user
        if serializer.is_valid():
            payment.product.claim_credits(payment.user, payment)
            serializer.save()
        else:
            return Response({'error':serializer.errors}, status=400)

    # this event happens when a checkout has not been paid or interacted with
    # sent after 30 minutes of inactivity
    if event['type'] == 'checkout.session.expired':
        #* delete unpaid payment object from DB
        payment = get_object_or_404(Payment, stripe_checkout_id=event['data']['object']['id'])
        payment.delete()

    # if the payment was not claimed, send a mail to user
    if event['type'] == 'payment_intent.canceled':

        payment = get_object_or_404(Payment, stripe_pi_id=event['data']['object']['id'])
        
        #* collect data for mail 
        context = {
            'customer_name':payment.user.username,
            'product_name':payment.product.name,
            'product_link':payment.product.id,
            'purchase_date':payment.time
        }

        #* configure and send mail
        subject = 'Payment was Cancelled'
        body = 'There was an error processing your payment. Please try again or contact support for assistance.'
        send_mail(
            subject,
            body,
            os.getenv('EMAIL_HOST_USER'),
            [payment.user.email]
        )

    # if payment was claimed, send a mail to user
    if event['type'] == 'payment_intent.succeeded':
        #* get product
        payment = get_object_or_404(Payment, stripe_pi_id=event['data']['object']['id'])

        #* collect data for mail 
        context = {
            'customer_name':payment.user.username,
            'product_name':payment.product.name,
            'product_link':payment.product.id,
            'purchase_date':payment.time
        }

        #* configure and send mail
        subject = 'Payment was Successfully Completed'
        body = 'Your payment was successfully processed. Thank you for your purchase!'
        send_mail(
            subject,
            body,
            os.getenv('EMAIL_HOST_USER'),
            [payment.user.email]
        )


    if 'charge.dispute.' in event['type']:            
        return HandleDispute(event)

    return  Response(status=204)