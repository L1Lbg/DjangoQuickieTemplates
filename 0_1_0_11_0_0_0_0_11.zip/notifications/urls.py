from django.urls import path
from . import views as notification_views

urlpatterns = [
    path('get', notification_views.get_notifications)
]